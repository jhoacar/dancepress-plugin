<a href="/wp-admin/admin.php?page=admin-manageparents"><?php _e('Back to Client Management page');?></a>

<h1><?php _e('Action on selected clients completed');?></h1>

<?php _e('Messages or confirmations sent to');?> <?=$data?> <?php _e('client(s)');?>.
