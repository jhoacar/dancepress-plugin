<a href="javascript: window.history.back();"><?php _e('Return to previous page');?></a>
