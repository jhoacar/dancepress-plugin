<?php foreach ($errors as $e):?>
<div class="ds-error error">
	<?=$e?>
</div>
<?php endforeach;?>

