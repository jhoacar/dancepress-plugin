<?php  foreach ($message as $m): ?>
	<div class="updated message fade">
		<?=$m?>
	</div>
<?php  endforeach;?>
